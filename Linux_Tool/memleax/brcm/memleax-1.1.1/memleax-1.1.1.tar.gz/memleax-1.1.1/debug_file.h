#ifndef MLD_DEBUG_FILE_H
#define MLD_DEBUG_FILE_H

void debug_try_init(const char *path, int exe_self);
const char *debug_try_get(void);

#endif
